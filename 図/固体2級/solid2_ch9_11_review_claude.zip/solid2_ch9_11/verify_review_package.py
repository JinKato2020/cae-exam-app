#!/usr/bin/env python3
"""納品ファイル検証。--app-root指定時は元データとの番号・選択肢数照合も行う。"""
import argparse,json,pathlib,re,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--app-root');a=p.parse_args();base=pathlib.Path(__file__).resolve().parent
D=json.loads((base/'solid2_ch9_11_final.json').read_text());Q=D['questions'];assert D['correctAnswerIndexBase']==1
want={f'{ch}-{i}' for ch,n in [(9,33),(10,41),(11,17)] for i in range(1,n+1)}
assert {q['number'] for q in Q}==want and len(Q)==len(want)==91
for q in Q:
 assert all(k in q for k in ['number','title','question','choices','answer','explanation'])
 assert len(q['choices'])==4 and type(q['answer']) is int and 1<=q['answer']<=4
 assert all(isinstance(q[k],str) and q[k].strip() for k in ['title','question','explanation'])
 assert not re.search(r'\\n(?![a-zA-Z])',q['explanation']);assert q['explanation'].count('$')%2==0
M=json.loads((base/'figure_manifest.json').read_text())['figures'];assert len(M)==40
for it in M:
 ET.parse(base/it['svg']);assert (base/it['png']).read_bytes()[:8]==b'\x89PNG\r\n\x1a\n'
 q=next(q for q in Q if q['number']==it['number']);key='preFigureImage' if it['stage']=='before' else 'figureImage';assert q[key]==it['target']
for q in Q:
 for k,st in [('preFigureImage','before'),('figureImage','after')]:
  if k in q:assert any(it['number']==q['number'] and it['stage']==st for it in M)
if a.app_root:
 root=pathlib.Path(a.app_root).resolve();idx={}
 for f in (root/'content'/'questions').glob('*.json'):
  if f.stem.startswith(('solid1-','thermal1-','thermal2-','vib1-','vib2-','solid2-')):continue
  for q in json.loads(f.read_text(encoding='utf-8')).get('questions',[]):
   n=q.get('number')
   if n in idx:raise SystemExit('FAIL: 分野内に重複番号 '+str(n))
   idx[n]=q
 for q in Q:
  if q['number'] not in idx:raise SystemExit('FAIL: 対象番号なし '+q['number'])
  if len(q['choices'])!=len(idx[q['number']].get('choices',[])):raise SystemExit('FAIL: 選択肢数不一致 '+q['number'])
 print('実アプリの番号・選択肢数照合 OK（読み取りのみ）')
print('PASS: 91問、1始まり正解、4択維持、40図、参照・UTF-8・SVG構文')
