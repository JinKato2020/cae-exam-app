# 固体2級 第9〜11章 レビュー・修正パック

対象：今回添付された回答前/回答後PDF、計91問（第9章33問、第10章41問、第11章17問）。

## Claudeへの指示（このパック全体を渡す）

1. 本文反映の正本は `solid2_ch9_11_final.json` 1本とする。`choices`・`answer`（1始まり）等のアプリ直系スキーマを使用している。章別MDやレビュー表を別途変換して反映しない。
2. 91問全件の解説を更新する。本文条件の補足は9-4、9-25、11-7、11-10、11-15の5問。選択肢の数・順序・正解番号は変更していない。
3. 図を変えるのは `figure_manifest.json` の21問・40点（回答前19、回答後21）だけ。正本に図フィールドがない70問は図設定を維持する。10-12と10-41は回答後のみ差し替えるため、回答前フィールドを追加・削除しない。
4. 既存アプリで `figureImage` / `preFigureImage` がどの形式のキーを受け取るか、既存画像登録と表示コードを最初に確認する。今回のキーは `assets/figures/solid2_review_ch9_11/<ファイル名>.png`。静的require登録を使う場合は `figure_import_map.ts` の同一キーを既存レジストリへ統合する。ファイル名を表示側で別解釈して、画像が消える状態を作らない。
5. 下記の事前照合・dry-runを実行し、番号不在・選択肢数不一致がゼロであることを確認して反映する。最後に実アプリの回答前後で全21問の画像参照と表示を確認する。回答前に回答後画像が表示されないこと、維持問の図が消えていないことも確認する。

## ファイル

- `solid2_ch9_11_final.json`：唯一の本文反映正本。
- `第9章_完成版.md`〜`第11章_完成版.md`：人が読むための完成原稿。
- `review_table.csv`：91問の確認・変更一覧。PDFページも記録。
- `レビュー結果.md`：主な問題点、対策、確認範囲。
- `figure_manifest.json`：今回の図専用一覧。既存 `deploy_recheck_figures.py` の内部仕様は提供されていないため、このmanifestの互換性は仮定していない。
- `figures/`：白背景・独立SVGと、同じSVGを描画した1200×630 PNG。PNGは配布用、SVGは編集用。
- `figures_preview.html`：回答前/回答後を並べたプレビュー。ZIPを展開してブラウザで開く。
- `deploy_review_figures.py`：本パック専用の図配置補助。生成済みPNGを配置するので再描画不要。
- `figure_import_map.ts`：アプリルートに置く場合の静的画像登録例。配置先が異なる場合はrequireの相対パスだけ調整する。
- `verify_review_package.py`：パック内部検証。アプリルート指定時は固体2級の実データと番号・選択肢数を照合。
- `apply_content.py`、`納品仕様_原本.md`：提供された反映スクリプト・仕様のコピー（内容未変更）。
- `calculation_checks.json`：独立計算で再確認した主要計算値。
- `validation_report.md`：実施した検証と未実施範囲。

## 反映手順

アプリルートをカレントディレクトリとし、ZIPを `review/solid2_ch9_11` に展開した例。パスに空白があるときは引用符で囲む。

```bash
# 1. 本パックと実アプリの照合（読み取りのみ）
python review/solid2_ch9_11/verify_review_package.py --app-root .

# 2. 本文dry-run。既存のtools/apply_content.pyを使う
python tools/apply_content.py review/solid2_ch9_11/solid2_ch9_11_final.json --field solid2

# 3. 画像配置dry-run
python review/solid2_ch9_11/deploy_review_figures.py --app-root .

# 4. 画像配置
python review/solid2_ch9_11/deploy_review_figures.py --app-root . --write

# 5. 静的画像登録が必要ならfigure_import_map.tsを既存レジストリへ統合

# 6. 本文反映（全3章を1回で反映）
python tools/apply_content.py review/solid2_ch9_11/solid2_ch9_11_final.json --field solid2 --write
```

アプリに `tools/apply_content.py` がない場合は、同梱の提供原本をその位置へコピーして使う。パック直下のコピーをそのまま実行すると、同スクリプトが推定するアプリルートが違うので使用しない。

重要：提供されたapply_content.pyは番号不在をスキップとして数え、必ずしもエラー終了しない。そのため、事前に本パックの `verify_review_package.py --app-root .` で番号不在を検出する。`FAIL=0` だけではなく、別分野スキップも0であることを確認する。

## 表示について

- 解説の改行は文字列内の実改行。KaTeX式は `$...$`。
- 図の簡潔な英語・数式ラベルは、日本語の本文・解説と対応する。例：shared＝共有、free＝自由、clamped＝固定、CCW＝反時計回り、inner/outer＝内側/外側。
- 図は条件理解のための模式図であり、未計算のFEMコンタを描いたものではない。11-5ははり理論式、11-10は例示半径比での対数温度分布を作図した。11-10の温度絶対値や円筒半径は設問の追加数値条件ではない。
- 10-41は色と数値を示す凡例説明で、実解析結果ではない。
- 実アプリのソース・画像ローダー・章JSONは今回提供されていない。アプリ上の反映・KaTeX表示・動作確認はClaude側で行う。今回完了したのは原稿・図素材と提供反映スクリプトの互換検証まで。
