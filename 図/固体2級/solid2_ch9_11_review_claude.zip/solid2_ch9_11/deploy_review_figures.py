#!/usr/bin/env python3
"""本パック専用。生成済みPNGを配置する（既存deploy_recheck_figures.pyの代替として独立使用）。"""
import argparse,json,pathlib,shutil,hashlib
p=argparse.ArgumentParser();p.add_argument('--app-root',required=True);p.add_argument('--write',action='store_true');a=p.parse_args()
base=pathlib.Path(__file__).resolve().parent;root=pathlib.Path(a.app_root).resolve();manifest=json.loads((base/'figure_manifest.json').read_text())['figures']
if not (root/'content'/'questions').is_dir():raise SystemExit('FAIL: content/questions がありません')
# 全件事前点検。欠損・意図しない既存ファイルの置換があれば一切配置しない。
for it in manifest:
 src=base/it['png'];dst=root/it['target']
 if not src.is_file():raise SystemExit('FAIL: '+str(src))
 if dst.exists() and hashlib.sha256(src.read_bytes()).digest()!=hashlib.sha256(dst.read_bytes()).digest():raise SystemExit('FAIL: 異なる既存画像があります: '+str(dst))
for it in manifest:
 src=base/it['png'];dst=root/it['target'];print(('COPY ' if a.write else 'PLAN ')+it['target'])
 if a.write:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
print('画像 '+str(len(manifest))+' 点。'+('配置完了。' if a.write else '確認後 --write で配置。'))
print('アプリが静的画像登録を使う場合は figure_import_map.ts のキーを登録してください。')
